$("body").css("background-color","rgb(49, 22, 75)");
$(".java").click(function (){
    $(".ball").css("margin-left","32px");
    $(".ball").css("background-color","white");
    $(".java").css("background-color","black");
    $("body").css("background-color","#161616");
})
